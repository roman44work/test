<?php

/**
 * Plugin Name: TestProperty
 * Description: Плагин для тестового задания
 * Plugin URI:
 * Author URI:
 * Author:      Roman
 * Version:     1.0
 * Text Domain: testproperty
 * Requires PHP: 5.4
 * License:  GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
	die;
}

define( 'TESTPROPERTY_PATH', plugin_dir_path( __FILE__ ) );


if ( ! class_exists( 'Test_Property_Post_Type' ) ) {
	require_once TESTPROPERTY_PATH . 'inc/class-test-property-post-type.php';
}

if ( ! class_exists( 'Gamajo_Template_Loader' ) ) {
	require_once TESTPROPERTY_PATH . 'inc/class-gamajo-template-loader.php';
}


require_once TESTPROPERTY_PATH . 'inc/class-test-property-template-loader.php';
require_once TESTPROPERTY_PATH . 'inc/class-test-property-shortcode.php';
require_once TESTPROPERTY_PATH . 'inc/class-test-property-widget.php';


class Test_Property {


	function register() {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action('widgets_init', [$this, 'register_widget']);
	}

	public function register_widget(){
		register_widget('test_property_widget');
	}



	public function enqueue_scripts() {
		wp_enqueue_style( 'bootstrap', plugins_url( '/assets/css/bootstrap.min.css', __FILE__ ) );
		wp_enqueue_style( 'testProperty-style', plugins_url( '/assets/css/style.css', __FILE__ ) );
		wp_enqueue_script( 'testProperty-script', plugins_url( '/assets/js/scripts.js', __FILE__ ), [ 'jquery' ], '1.0', true );

	}

	static function activation() {
		flush_rewrite_rules();
	}

	static function deactivation() {
		flush_rewrite_rules();
	}

	public function get_terms_hierarchical($tax_name,$current_term){
		$taxonomy_terms = get_terms($tax_name,['hide_empty'=>'false','parent'=>0]);
		$html = '';
		if(!empty($taxonomy_terms)){
			foreach($taxonomy_terms as $term){
				if($current_term == $term->term_id){
					$html .= '<option value="'.$term->term_id.'" selected >'.$term->name.'</option>';
				} else {
					$html .= '<option value="'.$term->term_id.'" >'.$term->name.'</option>';
				}
			}
		}
		return $html;
	}

}

if ( class_exists( 'Test_Property' ) ) {
	$testProperty = new Test_Property();
	$testProperty->register();

}

register_activation_hook( __FILE__, [ $testProperty, 'activation' ] );
register_deactivation_hook( __FILE__, [ $testProperty, 'deactivation' ] );





