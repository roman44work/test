<?php

if (!class_exists('Test_Property_Post_Type')){

	class Test_Property_Post_Type {
		public function register() {
			add_action( 'init', [ $this, 'custom_post_type' ] );
		}

		public function custom_post_type() {

			register_post_type( 'property',
				[
					'public'       => true,
					'has_archive'  => true,
					'rewrite'      => [ 'slug' => 'properties' ],
					'supports'     => [ 'title', 'editor', 'thumbnail' ],
					'show_in_rest' => true,
					'labels' => [
						'name'              => esc_html_x( 'Объект недвижимости', 'taxonomy general name', 'testproperty' ),
						'singular_name'     => esc_html_x( 'Объект недвижимости', 'taxonomy singular name', 'testproperty' ),
						'search_items'      => esc_html__( 'Найти объект недвижимости', 'testproperty' ),
						'all_items'         => esc_html__( 'Все объекты недвижимости', 'testproperty' ),
						'parent_item'       => esc_html__( 'Объект недвижимости', 'testproperty' ),
						'parent_item_colon' => esc_html__( 'Объект недвижимости:', 'testproperty' ),
						'edit_item'         => esc_html__( 'Редактировать объект недвижимости', 'testproperty' ),
						'update_item'       => esc_html__( 'Обновить объект недвижимости', 'testproperty' ),
						'add_new_item'      => esc_html__( 'Добавить новый объект недвижимости', 'testproperty' ),
						'new_item_name'     => esc_html__( 'Новый объект недвижимости', 'testproperty' ),
						'menu_name'         => esc_html__( 'Объект недвижимости', 'testproperty' ),
					]

				] );


			add_filter( 'post_edit_category_parent_dropdown_args', 'hide_parent_dropdown_select' );

			$args = [
				'show_ui' => true,
				'show_admin_column' => true,
				'query_var' => true,
				'show_in_rest' => true,
				'rewrite' => ['slug' => 'properties/location'],
				'labels' => [
					'name'              => esc_html_x( 'Район', 'taxonomy general name', 'testproperty' ),
					'singular_name'     => esc_html_x( 'Район', 'taxonomy singular name', 'testproperty' ),
					'search_items'      => esc_html__( 'Найти район', 'testproperty' ),
					'all_items'         => esc_html__( 'Все районы', 'testproperty' ),
					'parent_item'       => esc_html__( 'Район', 'testproperty' ),
					'parent_item_colon' => esc_html__( 'Район:', 'testproperty' ),
					'edit_item'         => esc_html__( 'Редактировать район', 'testproperty' ),
					'update_item'       => esc_html__( 'Обновить район', 'testproperty' ),
					'add_new_item'      => esc_html__( 'Добавить район', 'testproperty' ),
					'new_item_name'     => esc_html__( 'Новый район', 'testproperty' ),
					'menu_name'         => esc_html__( 'Районы', 'testproperty' ),
				]

			];
			register_taxonomy( 'location', 'property', $args );
		}
	}
}


if ( class_exists( 'Test_Property_Post_Type' ) ) {
	$testPropertyPostType = new Test_Property_Post_Type();
	$testPropertyPostType -> register();

}
