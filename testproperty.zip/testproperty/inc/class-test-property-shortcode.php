<?php

class Test_Property_Shortcode {

	public $testProperty;

	public function register() {
		add_action( 'init', [ $this, 'register_shortcode' ] );
	}

	public function register_shortcode() {
		add_shortcode( 'test-property', [ $this, 'filter_shortcode' ] );
	}

	public function filter_shortcode() {

		$this->testProperty = new Test_Property();

		$output = '';
//location
		$output = '<div class="container-wrap">';
		$output .= '<form class="form-css" method="POST"action="' . get_post_type_archive_link( 'property' ) . '">';
		$output .= '<select name="property_location">
            <option value="">Выберете район</option>' . $this->testProperty->get_terms_hierarchical( 'location', '' ) . '</select>';
		$loop = new WP_Query(
			[
				'post_type'      => 'property',
				'posts_per_page' => - 1,
			]
		);
//address
		$output .= '<select name="property_address">';
		$output .= '<option value="">Выберете адрес</option>';
		while ( $loop->have_posts() ) : $loop->the_post();
			$building_loc = get_field( 'building_loc' );
			$output .= '<option value="' . $building_loc . '">' . $building_loc . '</option>';
		endwhile;
		$output .= '</select>';

//name
		$output .= '<select name="property_name">';
		$array_building_name = [];
		$output .= '<option value="">Выберете название дома</option>';
		while ( $loop->have_posts() ) : $loop->the_post();
			$building_name = get_field( 'building_name' );
			if ( ! ( in_array( $building_name, $array_building_name ) ) ) {
				$output .= '<option value="' . $building_name . '">' . $building_name . '</option>';
			}
			$array_building_name[] = $building_name;
		endwhile;
		$output .= '</select>';

//floors
		$output .= '<select name="property_floors">';
		$array_number_floors = [];
		$output .= '<option value="">Выберете количество этажей</option>';
		while ( $loop->have_posts() ) : $loop->the_post();
			$number_floors = get_field( 'number_floors' );
			if ( ! ( in_array( $number_floors, $array_number_floors ) ) ) {
				$output .= '<option value="' . $number_floors . '">' . $number_floors . '</option>';
			}
			$array_number_floors[] = $number_floors;
		endwhile;
		$output .= '</select>';


//type
		$output .= '<div class="form-check">';
		$arr_radio = [];
		while ( $loop->have_posts() ) : $loop->the_post();
			$excludeDub = get_field( 'building_type' );
			if ( ! ( in_array( $excludeDub, $arr_radio ) ) ) {
				$output .= '<label><input type="radio" name="building_type" value="' . $excludeDub .'"/>'. $excludeDub .'</label>';
			}
			$arr_radio [] = $excludeDub;
		endwhile;
		$output .= '</div>';

		$output .= '<input type="submit" name="submit" value="фильтр"/>';

		$output .= '</form>';
		$output .= '</div>';

		return $output;
	}
}

$test_Property_Shortcode = new Test_Property_Shortcode();
$test_Property_Shortcode->register();

