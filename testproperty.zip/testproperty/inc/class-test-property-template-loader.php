<?php

class Test_Property_Template_Loader extends Gamajo_Template_Loader {
	protected $filter_prefix = 'testproperty';
	protected $theme_template_directory = 'testproperty';
	protected $plugin_directory = TESTPROPERTY_PATH;
	protected $plugin_template_directory = 'templates';

	public function register() {
		add_filter( 'template_include', [ $this, 'test_properties_template' ] );
	}

	public function test_properties_template( $template ) {

		if ( is_post_type_archive( 'property' ) ) {
			$theme_files = [
				'archive-property.php',
				'property/archive-property.php',
			];
			$exist       = $this->locate_template( $theme_files, false );
			if ( $exist != '' ) {
				return $exist;
			} else {
				return plugin_dir_path( __DIR__ ) . 'templates/archive-property.php';
			}
		} elseif ( is_singular( 'property' ) ) {
			$theme_files = [
				'single-property.php',
				'property/single-property.php',
			];
			$exist       = $this->locate_template( $theme_files, false );
			if ( $exist != '' ) {
				return $exist;
			} else {
				return plugin_dir_path( __DIR__ ) . 'templates/single-property.php';
			}
		}

		return $template;
	}
}

$testProperty_Template = new Test_Property_Template_Loader();

$testProperty_Template->register();
