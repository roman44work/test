<?php get_header(); ?>

<?php $testProperty_Template->get_template_part( 'filters' ) ?>
<div class="container">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
		<?php

		if ( ! empty( $_POST['submit'] ) ) {
			$args = [
				'post_type'      => 'property',
//				'posts_per_page' => -1,
				'meta_query'     => [ 'relation' => 'AND' ],
				'tax_query'      => [ 'relation' => 'AND' ],

				'posts_per_page' => 3,
				'paged'          => get_query_var( 'page' ),

			];


			if ( isset( $_POST['property_address'] ) && $_POST['property_address'] != '' ) {
				array_push( $args['meta_query'], [
					'key'   => 'building_loc',
					'value' => $_POST['property_address'],
				] );
			}

			if ( isset( $_POST['property_name'] ) && $_POST['property_name'] != '' ) {
				array_push( $args['meta_query'], [
					'key'   => 'building_name',
					'value' => $_POST['property_name'],
				] );
			}


			if ( isset( $_POST['property_floors'] ) && $_POST['property_floors'] != '' ) {
				array_push( $args['meta_query'], [
					'key'   => 'number_floors',
					'value' => $_POST['property_floors'],
				] );
			}


			if ( isset( $_POST['building_type'] ) && $_POST['building_type'] != '' ) {
				array_push( $args['meta_query'], [
					'key'   => 'building_type',
					'value' => $_POST['building_type'],
				] );
			}


			if(isset($_POST['property_location']) && $_POST['property_location'] != ''){
				array_push($args['tax_query'],array(
					'taxonomy' => 'location',
					'terms' => $_POST['property_location'],
				));
			}



			$properties = new WP_Query( $args );

			if ( $properties->have_posts() ) {
				while ( $properties->have_posts() ) {
					$properties->the_post();
					$testProperty_Template->get_template_part( 'content' );
				}
			} else {
				echo 'no properties';
			}

		} else {
			if ( have_posts() ) {
				while ( have_posts() ) {
					the_post();
					$testProperty_Template->get_template_part( 'content' );
				}

			} else {
				echo 'no properties';
			}
		}
		wp_reset_postdata();

		?>


    </div>
    
    
    <div class='d-flex mt-5 '>
        <button class="previous m-1">
            Previous
        </button>
        <div class="pagination-numbers m-1"></div>
        <button class="next m-1">
            Next
        </button>
    </div>

    
</div>
<?php get_footer(); ?>
