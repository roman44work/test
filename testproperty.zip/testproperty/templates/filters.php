<div class='container-wrap'>


 <?php $tProperty = new Test_Property(); ?>

<?php //$options = get_option('aleproperty_settings_options');
//
//	if(isset($options['filter_title'])){ echo esc_html($options['filter_title']); }
//    ?>

    <form class='form-css' method='POST' action="<?php get_post_type_archive_link( 'property' ) ?>">

        <select name="property_location">
            <option value="">Выберете район</option>
			<?php echo $tProperty->get_terms_hierarchical( 'location', $_POST['property_location'] ); ?>
        </select>
		<?php
		$loop = new WP_Query(
			[
				'post_type'      => 'property',
				'posts_per_page' => - 1,
			]
		);
		//address
		echo '<select name="property_address">
        <option value="">Выберете адрес</option>';
		while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<?php $building_loc = get_field( 'building_loc' ); ?>
            <option value='<?php echo $building_loc; ?>'
				<?php if ( isset( $_POST['property_address'] ) and $_POST['property_address'] == $building_loc ) {
					echo 'selected';
				} ?>>
				<?php echo $building_loc ?>
            </option>;
		<?php endwhile;
		echo '</select>';
		wp_reset_postdata();

		//name
		echo '<select name="property_name">
            <option value="">Выберете название дома</option>';
		$array_building_name = [];
		while ( $loop->have_posts() ) : $loop->the_post();
			$building_name = get_field( 'building_name' );
			if ( ! ( in_array( $building_name, $array_building_name ) ) ):?>
                <option value='<?php echo $building_name ?>'
					<?php if ( isset( $_POST['property_name'] ) and $_POST['property_name'] == $building_name ) {
						echo 'selected';
					} ?>>
					<?php echo $building_name ?>
                </option>;
				<?php
				$array_building_name[] = $building_name;
			endif; ?>
		<?php endwhile;
		echo '</select>';
		wp_reset_postdata();


		//floors
		echo '<select name="property_floors">
            <option value="">Выберете количество этажей</option>';
		$array_number_floors = [];
		while ( $loop->have_posts() ) : $loop->the_post();
			$number_floors = get_field( 'number_floors' );
			if ( ! ( in_array( $number_floors, $array_number_floors ) ) ):?>
                <option value='<?php echo $number_floors; ?>'
					<?php if ( isset( $_POST['property_floors'] ) and $_POST['property_floors'] == $number_floors ) {
						echo 'selected';
					} ?>>
					<?php echo $number_floors ?>
                </option>;
				<?php
				$array_number_floors[] = $number_floors;
			endif; ?>
		<?php endwhile;
		echo '</select>';
		wp_reset_postdata();


		//type
		?>
        <div class='form-check'>
			<?php
			$arr_radio = [];
			while ( $loop->have_posts() ) : $loop->the_post(); ?>
				<?php
				$excludeDub = get_field( 'building_type' );
				if ( ! ( in_array( $excludeDub, $arr_radio ) ) ):?>
                    <label>
                        <input type="radio" name="building_type" value="<?php echo $excludeDub ?>"
							<?php if ( isset( $_POST['building_type'] ) and $_POST['building_type'] == $excludeDub ) {
								echo 'checked';
							} ?>
                        />
						<?php echo $excludeDub ?>
                    </label>
					<?php
					$arr_radio [] = $excludeDub;
				endif;

				?>
			<?php endwhile;
			wp_reset_postdata();
			?>
        </div>
        <input type="submit" name="submit" value="фильтр"/>
    </form>
</div>