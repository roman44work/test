<?php get_header(); ?>
<div class="container">
	<?php if ( have_posts() ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
            <div class="col" id='post-<?php the_ID(); ?>' <?php post_class(); ?>>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h4 class='mb-3'><?php the_title() ?></h4>
                        <div class="card-text mb-3"><?php the_content(); ?></div>
                        <ul class="list-group">
                            <li class="list-group-item"><span>Район:</span>
								<?php

								$locations = get_the_terms( get_the_ID(), 'location' );
								if ( $locations ) {
									foreach ( $locations as $location ) {
										echo $location->name;
									}
								}
								?>
                            </li>
                            <li class="list-group-item"><span>Название дома:</span> <?php the_field( 'building_name' ); ?></li>
                            <li class="list-group-item"><span class='tit-li'>Координаты местонахождения:</span> <?php the_field( 'building_loc' ); ?></li>
                            <li class="list-group-item"><span>Количество этажей:</span> <?php the_field( 'number_floors' ); ?></li>
                            <li class="list-group-item"><span>Тип строения:</span> <?php the_field( 'building_type' ); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
		<?php endwhile; ?>
		<?php posts_nav_link(); ?>
	<?php else: ?>
		<?php echo 'no posts' ?>
	<?php endif; ?>
    <!--    </div>-->
</div>
<?php get_footer(); ?>
