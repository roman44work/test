<?php

$properties = get_posts( [
	'post_type'   => 'property',
	'numberposts' => - 1,
] );

foreach ( $properties as $property ) {
	wp_delete_post($property -> ID, true);
}
